#include<stdio.h>
#include<iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
uint32_t current_x[4] = {0x08, 0x04, 0x02, 0x01};//t18-t20-t22-t24
uint32_t y[9] = {0};
int idx_y[6][4] = {
{6, 3, 7, 5},
{6, 8, 1},
{2, 5, 8},
{8, 5, 1, 0}, 
{4, 3, 0, 7}, 
{4, 8, 2} 
};
// {43, 24, 44, 42},
// {43, 45, 22},
// {23, 42, 45},
// {45, 42, 22, 21}, 
// {41, 24, 21, 44}, 
// {41, 45, 23} 
// };
int len_y[6] = {4, 3, 3, 4, 4, 3};
vector<int> idx_chsn;       //among t21-t22-t23-t24, which variables have been used to store y[];
int xor_gate_count = 0;
int MAX_XOR_GATE_COUNT = 100;

void Top_Function_U(uint32_t *x)
{
	y[0] = x[0];//t21
	y[1] = x[1];//t22
	y[2] = x[2];//t23
	y[3] = x[3];//t24

	y[4] = x[1]^x[3];//t41
	y[5] = x[0]^x[2];//t42
	y[6] = x[0]^x[1];//t43
	y[7] = x[2]^x[3];//t44
	y[8] = x[0]^x[1]^x[2]^x[3];//t45
}

bool find_element(vector<int>chsn_idx, int dst)
{
	vector<int>::iterator iter = find(chsn_idx.begin(), chsn_idx.end(), dst);
	if(iter != chsn_idx.end())
	{
		return false;
	}
	return true;
}

vector<int> delete_chosen(vector<int> a, vector<int> b)
{
	vector<int> result;
	for(int i = 0; i < a.size(); i++)
	{
		if(find_element(b, a[i]) == true)
		{
			result.push_back(a[i]);
		}	
	}
	return result;
}

bool random_idx(uint32_t trt, uint32_t *x, int r, int c, vector<vector<int>> &c_imp)
{
	vector<int> operation;
	for(int i = 0; i < 4; i++)
	{
		if(((trt>>i)&1) == 1)
		{//0123
			operation.push_back(3 - i);
		}
	}

	xor_gate_count += (operation.size() - 1);
	vector<int> candidate_idx = delete_chosen(operation, idx_chsn);
	
	if(candidate_idx.size() == 0)
	{
		return false;
	}

	else if(candidate_idx.size() > 0)
	{
		int tgt_idx = rand()%(candidate_idx.size());
		vector<int> row;
		row.push_back(candidate_idx[tgt_idx]);
		row.insert(row.begin() + 1, operation.begin(), operation.end());

		x[candidate_idx[tgt_idx]] = y[idx_y[r][c]];
		idx_chsn.push_back(candidate_idx[tgt_idx]);
		c_imp.push_back(row);
	}
	return true;
}

void compute_col(uint32_t *x, int r, int c,  vector<vector<int>> &c_imp)
{
	for(uint32_t i = 1; i < 16; i++)
	{//0123
		uint32_t sum = 0; 
		for(int j = 0; j < 4; j++)
		{
			sum ^= (((i>>j)&1) * x[3 - j]);
		}
		if(sum == y[idx_y[r][c]])
		{
			bool rst = random_idx(i, x, r, c, c_imp);
			if(rst == false)
			{
				cout<<" No solution here!"<<endl;
				exit(0);
			}
		}
	}
}

void print_imp( vector<vector<int>> c_imp)
{
	ofstream f;
	f.open("Reduced_Result_t_for_S-box.txt");
	f <<"         ---MAX_XOR_GATE_COUNT = "<<MAX_XOR_GATE_COUNT<<endl;
	for(int i = 0; i < c_imp.size(); i++)
	{
		f <<"x["<<c_imp[i][0]<<"] = ";
		for(int j = 1; j < c_imp[i].size() - 1; j++)
		{
			f <<"x["<<c_imp[i][j]<<"] ^ ";
		}
		f <<"x["<<c_imp[i][c_imp[i].size() - 1]<<"];"<<endl;
	}
	//x0:t21
	//x1:t22
	//x3:t23
	//x4:t24
	f.close();
}

void expand_y(uint32_t *x, vector<vector<int>> &c_imp)
{
	for(int i = 0; i < 6; i++)
	{
		idx_chsn.erase(idx_chsn.begin(), idx_chsn.end());
		for(int j = 0; j < len_y[i]; j++)
		{ 
			compute_col(x, i, j, c_imp);
		}
	}

	if(MAX_XOR_GATE_COUNT > xor_gate_count)
	{
		MAX_XOR_GATE_COUNT = xor_gate_count;
		cout<<"Find an implememtation with "<<MAX_XOR_GATE_COUNT<<" XOR gates"<<endl;
		print_imp(c_imp);
	}
}

void initialize()
{
	current_x[0] = 0x08;
	current_x[1] = 0x04;
	current_x[2] = 0x02;
	current_x[3] = 0x01;
	xor_gate_count = 0;
}

int main()
{
	for(int i = 0; ; i++)
	{
		vector<vector<int>> current_imp;
		initialize();
		Top_Function_U(current_x);
		expand_y(current_x, current_imp);	
	}
	return 0;
}