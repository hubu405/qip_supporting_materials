#include<stdio.h>
#include<iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
uint32_t current_x[8] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};//x0-x1-x2-...-x7
uint32_t y[22] = {0};

int idx_y[13][8] = {
{12, 15, 4,  0,  14, 17, 2, 7},
{13, 16, 3,  6,   8, 10, 9, 11},
{9,  11, 8, 10,   5,  1,13, 16},
{20}, 
{19}, 
{21}, 
{18},
{16, 9,15, 3},
{13, 9, 1, 14},
{0, 12,17, 2},
{17, 7, 6, 11},
{10, 14},
{8,  5, 4}
};
int len_y[13] = {8, 8, 8, 1, 1, 1, 1, 4, 4, 4, 4, 2, 3};
int idx_y_xored_1[22] = {1,1,1,0,1,1,1,0,1,0,0,1,1,0,1,0,1,1,1,1,1,1};
int flag_x_xored_1[8] = {0};//to mark whether x[i] has been xored "1" or not.
vector<int> idx_chsn;       //among x[0], x[1],...,x[7], which variables have been used to store y[];
int xor_gate_count = 0;
int MAX_XOR_GATE_COUNT = 1000;
int not_gate_count = 0;
int MAX_NOT_GATE_COUNT = 1000;

struct IMP
{
	vector<int> operators;
	int flag_x_gate;
};

void Top_Function_U(uint32_t *x)
{//delete '^1', since we have 'idx_y_xored_1[22]''
	y[0] = x[5] ^ x[2] ^ x[0];
	y[1] = x[7] ^ x[4] ^ x[3];
	y[2] = x[6] ^ x[1] ^ x[7] ^ x[4];
	y[3] = x[0] ^ x[3];
	y[4] = x[7] ^ x[3] ^ x[6] ^ x[1];
	y[5] = x[3] ^ x[1];
	y[6] = x[3] ^ x[1] ^ x[0];
	y[7] = x[6] ^ x[3] ^ x[7] ^ x[1] ^ x[2];
	y[8] = x[1] ^ x[0];
	y[9] = x[3] ^ x[4];
	y[10] = x[0] ^ x[7] ^ x[4] ^ x[1];
	y[11] = x[5] ^ x[6] ^ x[3] ^ x[0] ^ x[7] ^ x[1];
	y[12] = x[6] ^ x[0] ^ x[7] ^ x[1];
	y[13] = x[6] ^ x[3] ^ x[7] ^ x[4];
	y[14] = x[4] ^ x[1] ^ x[3] ^ x[0];
	y[15] = x[3] ^ x[1] ^ x[5] ^ x[2];
	y[16] = x[2] ^ x[4] ^ x[1] ^ x[6];
	y[17] = x[5] ^ x[4] ^ x[6] ^ x[3];
	y[18] = x[2] ^ x[3] ^ x[4];
	y[19] = x[7] ^ x[4];
	y[20] = x[5] ^ x[6] ^ x[0] ^ x[7] ^ x[4] ^ x[1];
	y[21] = x[1] ^ x[7] ^ x[2] ^ x[3];
}

bool find_element(vector<int>chsn_idx, int dst)
{
	vector<int>::iterator iter = find(chsn_idx.begin(), chsn_idx.end(), dst);
	if(iter != chsn_idx.end())
	{
		return false;
	}
	return true;
}

vector<int> delete_chosen(vector<int> a, vector<int> b)
{
	vector<int> result;
	for(int i = 0; i < a.size(); i++)
	{
		if(find_element(b, a[i]) == true)
		{
			result.push_back(a[i]);
		}	
	}
	return result;
}

bool random_idx(uint32_t trt, uint32_t *x, int r, int c, vector<IMP> &c_imp)
{
	vector<int> operation;
	for(int i = 0; i < 8; i++)
	{
		if(((trt>>i)&1) == 1)
		{//01234567
			operation.push_back(7 - i);
		}
	}

	xor_gate_count += (operation.size() - 1);
	vector<int> candidate_idx = delete_chosen(operation, idx_chsn);
	
	if(candidate_idx.size() == 0)
	{
		return false;
	}

	else if(candidate_idx.size() > 0)
	{
		int tgt_idx = rand()%(candidate_idx.size());
		IMP row;
		row.operators.push_back(candidate_idx[tgt_idx]);
		row.operators.insert(row.operators.begin() + 1, operation.begin(), operation.end());
		int not_gate_flag = 0;
		for(int i = 0; i < operation.size(); i++)
		{	
			not_gate_flag ^= flag_x_xored_1[operation[i]];
		}
		
		flag_x_xored_1[candidate_idx[tgt_idx]] = idx_y_xored_1[idx_y[r][c]];
		if(not_gate_flag != idx_y_xored_1[idx_y[r][c]])
		{
		    row.flag_x_gate = 1;
			not_gate_count += 1;
		}
		else if(not_gate_flag == idx_y_xored_1[idx_y[r][c]])
		{
			row.flag_x_gate = 0;
		}
		
		x[candidate_idx[tgt_idx]] = y[idx_y[r][c]];
		idx_chsn.push_back(candidate_idx[tgt_idx]);
		c_imp.push_back(row);
	}
	return true;
}

void compute_col(uint32_t *x, int r, int c, vector<IMP> &c_imp)
{
	for(uint32_t i = 1; i < 256; i++)
	{//01234567
		uint32_t sum = 0; 
		for(int j = 0; j < 8; j++)
		{
			sum ^= (((i>>j)&1) * x[7 - j]);
		}
		if(sum == y[idx_y[r][c]])
		{
			bool rst = random_idx(i, x, r, c, c_imp);
			if(rst == false)
			{
				cout<<" No solution here!"<<endl;
				exit(0);
			}
		}
	}
}

void print_imp(vector<IMP> c_imp)
{
	ofstream f;
	f.open("Reduced_Result_for_invSB_from_BP.txt");
	f <<"         ---MAX_XOR_GATE_COUNT - MAX_NOT_GATE_COUNT = "<<MAX_XOR_GATE_COUNT<<" - "<<MAX_NOT_GATE_COUNT<<endl;
	for(int i = 0; i < c_imp.size(); i++)
	{
		f <<"x["<<c_imp[i].operators[0]<<"] = ";
		for(int j = 1; j < c_imp[i].operators.size() - 1; j++)
		{
			f <<"x["<<c_imp[i].operators[j]<<"] ^ ";
		}
		f <<"x["<<c_imp[i].operators[c_imp[i].operators.size() - 1]<<"]";
		if(c_imp[i].flag_x_gate == 1)
		{
			f <<" ^ 1";
		}
		f <<";"<<endl;
	}
	f.close();
}

void expand_y(uint32_t *x, vector<IMP> &c_imp)
{
	for(int i = 0; i < 13; i++)
	{
		//cout<<i<<endl;
		idx_chsn.erase(idx_chsn.begin(), idx_chsn.end());
		for(int j = 0; j < len_y[i]; j++)
		{ 
			compute_col(x, i, j, c_imp);
		}
	}

	if(MAX_XOR_GATE_COUNT > xor_gate_count)
	{
		MAX_XOR_GATE_COUNT = xor_gate_count;
		MAX_NOT_GATE_COUNT = not_gate_count;
		cout<<"Find an implememtation with "<<MAX_XOR_GATE_COUNT<<" XOR gates and "<<MAX_NOT_GATE_COUNT<< " X gates" <<endl;
		print_imp(c_imp);
	}
	else if(MAX_XOR_GATE_COUNT == xor_gate_count)
	{
		if(MAX_NOT_GATE_COUNT > not_gate_count)
		{
			MAX_NOT_GATE_COUNT = not_gate_count;
			cout<<"Find an implememtation with "<<MAX_XOR_GATE_COUNT<<" XOR gates and "<<MAX_NOT_GATE_COUNT<< " X gates" <<endl;
			print_imp(c_imp);
		}
	}
}

void initialize()
{
	current_x[0] = 0x80;
	current_x[1] = 0x40;
	current_x[2] = 0x20;
	current_x[3] = 0x10;
	current_x[4] = 0x08;
	current_x[5] = 0x04;
	current_x[6] = 0x02;
	current_x[7] = 0x01;//x0-x1-x2-...-x7

	xor_gate_count = 0;
	not_gate_count = 0;

	for(int i = 0; i < 8; i++)
	{
		flag_x_xored_1[i] = 0;
	}
}

int main()
{
	for(int i = 0; ; i++)
	{
		vector<IMP> current_imp;
		initialize();
		Top_Function_U(current_x);
		expand_y(current_x, current_imp);	
	}
	return 0;
}