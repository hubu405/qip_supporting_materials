#include<stdio.h>
#include<iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
uint32_t current_x[8] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};//x0-x1-x2-...-x7
uint32_t y[22] = {0};
int idx_y[15][8] = {
{17, 16, 9,  8,  13, 12, 6, 2},
{11, 10, 15, 14, 7,  3,  4, 0},
{11, 10, 15, 14, 5,  1},
{21}, 
{20}, 
{19}, 
{18},
{14, 10, 8, 0},
{15, 11, 9,  4},
{13, 16, 2,  5},
{13, 16, 2,  5},
{1,  6,  7},
{7,  17, 12},
{3},
{3}
};

/*
void f_2(int *t, int *y, int *s)
{
	
	s[0] = s[0] ^ y[14] & t[42];
	s[6] = s[6] ^ y[10] & t[44]; 
	s[3] = s[3] ^ y[8] & t[45]; 
	s[5] = s[5] ^ y[0] & t[18]; 


	s[1] = s[1] ^ y[15] & t[42];
	s[2] = s[2] ^ y[11] & t[44];
	s[4] = s[4] ^ y[9] & t[45]; 
	s[7] = s[7] ^ y[4] & t[18];
	

	s[2] = s[2] ^ y[13] & t[43];
	s[3] = s[3] ^ y[16] & t[41];
	s[6] = s[6] ^ y[2] & t[22];
	s[4] = s[4] ^ y[5] & t[20];

	s[1] = s[1] ^ y[13] & t[43];
	s[0] = s[0] ^ y[16] & t[41];
	s[5] = s[5] ^ y[2] & t[22];
	s[7] = s[7] ^ y[5] & t[20];


	s[0] = s[0] ^ s[6];
	s[1] = s[1] ^ s[0];
	s[5] = s[5] ^ s[3];
	s[7] = s[7] ^ s[2];
	s[1] = s[1] ^ s[4];

	s[2] = s[2] ^ y[6] & t[22];
	s[3] = s[3] ^ y[1] & t[20];
	s[4] = s[4] ^ y[7] & t[24];


	s[2] = s[2] ^ y[7] & t[24];
	s[4] = s[4] ^ y[17] & t[41];
	s[6] = s[6] ^ y[12] & t[43];

	s[0] = s[0] ^ s[2];  
	s[2] = s[2] ^ s[3];
	s[3] = s[3] ^ s[6];

	s[2] = s[2] ^ y[3] & t[24];

	s[6] = s[6] ^ y[3] & t[24];


	s[6] = s[6] ^ s[1];  
	s[1] = s[1] ^ s[7];
	s[1] = s[1] ^ s[5];
	s[5] = s[5] ^ s[2];
	s[4] = s[4] ^ s[5];
}
*/
int len_y[15] = {8, 8, 6, 1, 1, 1, 1, 4, 4, 4, 4, 3, 3, 1, 1};
int idx_y_xored_1[22] = {0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0};
int flag_x_xored_1[8] = {0};//to mark whether x[i] has been xored "1" or not.
vector<int> idx_chsn;       //among x[0], x[1],...,x[7], which variables have been used to store y[];
int xor_gate_count = 0;
int MAX_XOR_GATE_COUNT = 1000;
int not_gate_count = 0;
int MAX_NOT_GATE_COUNT = 1000;

struct IMP
{
	vector<int> operators;
	int flag_x_gate;
};

void Top_Function_U(uint32_t *x)
{
	y[0] = x[5] ^ x[6] ^ x[3];
	y[1] = x[4] ^ x[5] ^ x[3] ^ x[1]; 
	y[2] = x[5] ^ x[0] ^ x[2] ^ x[1] ^ x[6];
	y[3] = x[5] ^ x[2] ^ x[6] ^ x[7]; 
	y[4] = x[5] ^ x[0]; 
	y[5] = x[1]; 
	y[6] = x[5] ^ x[0] ^ x[2] ^ x[1];
	y[7] = x[4] ^ x[1] ^ x[0]; 
	y[8] = x[4] ^ x[1] ^ x[6]; 
	y[9] = x[1] ^ x[5] ^ x[0]; 
	y[10] = x[6] ^ x[7] ^ x[4] ^ x[0]; 
	y[11] = x[1] ^ x[0] ^ x[2]^ x[4]; 
	y[12] = x[2] ^ x[3] ^ x[1] ^ x[0];
	y[13] = x[2] ^ x[1]; 
	y[14] = x[2] ^ x[6] ^ x[7] ^ x[4] ^ x[3] ^ x[1]; 
	y[15] = x[4] ^ x[0];
	y[16] = x[7] ^ x[1] ^ x[0];
	y[17] = x[5] ^ x[2]  ^ x[4]; 
	y[18] = x[6]; 
	y[19] = x[5] ^ x[2]  ^ x[4] ^ x[7] ^ x[1] ^ x[0];
	y[20] = x[4] ^ x[5] ^ x[0]; 
	y[21] = x[7] ^ x[2] ^ x[3] ^ x[1] ^ x[0];
}

bool find_element(vector<int>chsn_idx, int dst)
{
	vector<int>::iterator iter = find(chsn_idx.begin(), chsn_idx.end(), dst);
	if(iter != chsn_idx.end())
	{
		return false;
	}
	return true;
}

vector<int> delete_chosen(vector<int> a, vector<int> b)
{
	vector<int> result;
	for(int i = 0; i < a.size(); i++)
	{
		if(find_element(b, a[i]) == true)
		{
			result.push_back(a[i]);
		}	
	}
	return result;
}

bool random_idx(uint32_t trt, uint32_t *x, int r, int c, vector<IMP> &c_imp)
{
	vector<int> operation;
	for(int i = 0; i < 8; i++)
	{
		if(((trt>>i)&1) == 1)
		{//01234567
			operation.push_back(7 - i);
		}
	}

	xor_gate_count += (operation.size() - 1);
	vector<int> candidate_idx = delete_chosen(operation, idx_chsn);
	
	if(candidate_idx.size() == 0)
	{
		return false;
	}

	else if(candidate_idx.size() > 0)
	{
		int tgt_idx = rand()%(candidate_idx.size());
		IMP row;
		row.operators.push_back(candidate_idx[tgt_idx]);
		row.operators.insert(row.operators.begin() + 1, operation.begin(), operation.end());
		int not_gate_flag = 0;
		for(int i = 0; i < operation.size(); i++)
		{	
			not_gate_flag ^= flag_x_xored_1[operation[i]];
		}
		
		flag_x_xored_1[candidate_idx[tgt_idx]] = idx_y_xored_1[idx_y[r][c]];
		if(not_gate_flag != idx_y_xored_1[idx_y[r][c]])
		{
		    row.flag_x_gate = 1;
			not_gate_count += 1;
		}
		else if(not_gate_flag == idx_y_xored_1[idx_y[r][c]])
		{
			row.flag_x_gate = 0;
		}
		
		x[candidate_idx[tgt_idx]] = y[idx_y[r][c]];
		idx_chsn.push_back(candidate_idx[tgt_idx]);
		c_imp.push_back(row);
	}
	return true;
}

void compute_col(uint32_t *x, int r, int c, vector<IMP> &c_imp)
{
	for(uint32_t i = 1; i < 256; i++)
	{//01234567
		uint32_t sum = 0; 
		for(int j = 0; j < 8; j++)
		{
			sum ^= (((i>>j)&1) * x[7 - j]);
		}
		if(sum == y[idx_y[r][c]])
		{
			bool rst = random_idx(i, x, r, c, c_imp);
			if(rst == false)
			{
				cout<<" No solution here!"<<endl;
				exit(0);
			}
		}
	}
}

void print_imp(vector<IMP> c_imp)
{
	ofstream f;
	f.open("Reduced_Result_for_invSB_from_Zou.txt");
	f <<"         ---MAX_XOR_GATE_COUNT - MAX_NOT_GATE_COUNT = "<<MAX_XOR_GATE_COUNT<<" - "<<MAX_NOT_GATE_COUNT<<endl;
	for(int i = 0; i < c_imp.size(); i++)
	{
		f <<"x["<<c_imp[i].operators[0]<<"] = ";
		for(int j = 1; j < c_imp[i].operators.size() - 1; j++)
		{
			f <<"x["<<c_imp[i].operators[j]<<"] ^ ";
		}
		f <<"x["<<c_imp[i].operators[c_imp[i].operators.size() - 1]<<"]";
		if(c_imp[i].flag_x_gate == 1)
		{
			f <<" ^ 1";
		}
		f <<";"<<endl;
	}
	f.close();
}

void expand_y(uint32_t *x, vector<IMP> &c_imp)
{
	for(int i = 0; i < 15; i++)
	{
		idx_chsn.erase(idx_chsn.begin(), idx_chsn.end());
		for(int j = 0; j < len_y[i]; j++)
		{ 
			compute_col(x, i, j, c_imp);
		}
	}

	if(MAX_XOR_GATE_COUNT > xor_gate_count)
	{
		MAX_XOR_GATE_COUNT = xor_gate_count;
		MAX_NOT_GATE_COUNT = not_gate_count;
		cout<<"Find an implememtation with "<<MAX_XOR_GATE_COUNT<<" XOR gates and "<<MAX_NOT_GATE_COUNT<< " X gates" <<endl;
		print_imp(c_imp);
	}
	else if(MAX_XOR_GATE_COUNT == xor_gate_count)
	{
		if(MAX_NOT_GATE_COUNT > not_gate_count)
		{
			MAX_NOT_GATE_COUNT = not_gate_count;
			cout<<"Find an implememtation with "<<MAX_XOR_GATE_COUNT<<" XOR gates and "<<MAX_NOT_GATE_COUNT<< " X gates" <<endl;
			print_imp(c_imp);
		}
	}
}

void initialize()
{
	current_x[0] = 0x80;
	current_x[1] = 0x40;
	current_x[2] = 0x20;
	current_x[3] = 0x10;
	current_x[4] = 0x08;
	current_x[5] = 0x04;
	current_x[6] = 0x02;
	current_x[7] = 0x01;//x0-x1-x2-...-x7

	xor_gate_count = 0;
	not_gate_count = 0;

	for(int i = 0; i < 8; i++)
	{
		flag_x_xored_1[i] = 0;
	}
}

int main()
{
	for(int i = 0; ; i++)
	{
		vector<IMP> current_imp;
		initialize();
		Top_Function_U(current_x);
		expand_y(current_x, current_imp);	
	}
	return 0;
}