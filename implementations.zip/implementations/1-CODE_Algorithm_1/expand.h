#include <bitset>
#include <vector>

#ifndef Q_SBOX_EXPAND_H
#define Q_SBOX_EXPAND_H

using namespace std;

enum value_type {
    t21,
    t22,
    t23,
    t24,
    a,
    s0,
    s1,
    s2,
    s3,
    s4,
    s5,
    s6,
    s7
};

typedef std::bitset<8> type_y;


typedef std::bitset<4> type_t;


struct expression_t{
    int index;
    value_type t;
    type_y middle;
    type_y right;
};


struct expression_t2{
    int index;
    value_type t;
    type_t middle;
    type_y right;
};

struct barrier{
    int index;
    value_type t;
};

extern const  type_y y[22];


typedef std::vector<expression_t> par_C;

typedef std::vector<expression_t2> par_C2;

int optimize_U();

int optimize_B();

void execute_expand();

void execute_expand_t();

#endif //Q_SBOX_EXPAND_H
