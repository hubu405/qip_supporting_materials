#include <bitset>
#include <vector>
#include <iostream>


using namespace std;

enum v_type {
    x0, x1, x2, x3, x4, x5, x6, x7,
    y0, y1, y2, y3, y4, y5, y6, y7, y8, y9,
    y10, y11, y12, y13, y14, y15, y16,
    y17, y18, y19, y20, y21,
    t21, t22, t23, t24, t41, t42, t43, t44, t45,
};


struct expression_t3 {
    v_type v;
    vector<v_type> gen;
};

struct result {
    v_type v1;
    v_type v2;
    vector<v_type> gen;
};

typedef vector<v_type> classified;

#define Y 0
#define T 1

#define EPAND_TYPE T


#if EPAND_TYPE == Y

vector<expression_t3> state_cpy{
        {x0,  {x0}},
        {x1,  {x1}},
        {x2,  {x2}},
        {x3,  {x3}},
        {x4,  {x4}},
        {x5,  {x5}},
        {x6,  {x6}},
        {x7,  {x7}},
        {y0,  {x7}},
        {y1,  {x1, x2, x7}},
        {y2,  {x0, x1, x2, x7}},
        {y3,  {x0, x1, x2, x5, x6, x7}},
        {y4,  {x1, x2, x3, x7}},
        {y5,  {x1, x2, x6, x7}},
        {y6,  {x0, x3, x4, x6, x7}},
        {y7,  {x1, x4, x5, x6, x7}},
        {y8,  {x0, x5}},
        {y9,  {x0, x3}},
        {y10, {x0, x1, x2, x3, x4, x6}},
        {y11, {x1, x4, x5, x6}},
        {y12, {x0, x3, x5, x6}},
        {y13, {x0, x6}},
        {y14, {x3, x5}},
        {y15, {x0, x3, x4, x6}},
        {y16, {x2, x4, x6, x5}},
        {y17, {x0, x2, x3, x5}},
        {y18, {x0, x2, x4, x5, x6}},
        {y19, {x1, x2, x3, x4, x5, x6}},
        {y20, {x0, x1, x3, x4, x5, x6}},
        {y21, {x0, x2, x4, x5}}
};


vector<classified> groups{
        {y12,y15,y4,y0,y14,y17,y2,y7},
        {y13,y16,y3,y6,y8,y10,y9,y11},
        {y8,y10,y5,y1,y13,y16,y9,y11},
        {y20},
        {y19},
        {y21},
        {y18},
        {y16,y3,y15,y9},
        {y13,y14,y1},
        {y0,y9,y17},
        {y17,y11,y5,y2},
        {y10,y6,y7,y12,},
        {y8,y14,y4}
};


#elif EPAND_TYPE == T
vector<expression_t3> state_cpy{
        {t21, {t21}},
        {t22, {t22}},
        {t23, {t23}},
        {t24, {t24}},
        {t41, {t22,t24}},
        {t42, {t21,t23}},
        {t43, {t21,t22}},
        {t44, {t23,t24}},
        {t45, {t21, t22,t23, t24}}
};

vector<classified> groups{
        {t43,t24,t44,t42},
        {t43,t45,t22},
        {t23,t42,t45},
        {t45,t42,t22,t21},
        {t41,t24,t21,t44},
        {t41,t45,t23}




};

#endif

vector<expression_t3> state;

bool in(v_type t, const vector<v_type> &used) {
    auto res = find(begin(used), end(used), t);
    if (res == end(used))
        return false;
    else return true;
}

v_type select_and_prep_list(v_type yi, vector<v_type> &list, const vector<v_type> &used) {
    for (auto s: state) {
        if (s.v == yi) {
            int size = s.gen.size();
            int rep;
            do {
                srand(time(NULL));
                rep = rand() % size;
            } while (in(s.gen[rep], used));
            list.insert(list.begin(), s.gen.begin(), s.gen.end());
            auto x = find(list.begin(), list.end(), s.gen[rep]);
            list.erase(x);
            return s.gen[rep];
        }
    }
}

void add(vector<v_type> &gen, const vector<v_type> &list) {
    for (auto x: list) {
        auto res = find(begin(gen), end(gen), x);
        if (res == end(gen))
            gen.push_back(x);
        else gen.erase(res);
    }
}

void update_state(const vector<v_type> &list, const v_type &rep) {
    int n = state.size();
    for (int i = 0; i < n; ++i) {
        if (in(rep, state[i].gen)) {
            add(state[i].gen, list);
        }
    }
}

void print_v_type(v_type v) {
    switch (v) {
        case x0:
            cout << "x0";
            break;
        case x1:
            cout << "x1";
            break;
        case x2:
            cout << "x2";
            break;
        case x3:
            cout << "x3";
            break;
        case x4:
            cout << "x4";
            break;
        case x5:
            cout << "x5";
            break;
        case x6:
            cout << "x6";
            break;
        case x7:
            cout << "x7";
            break;
        case y0:
            cout << "y0";
            break;
        case y1:
            cout << "y1";
            break;
        case y2:
            cout << "y2";
            break;
        case y3:
            cout << "y3";
            break;
        case y4:
            cout << "y4";
            break;
        case y5:
            cout << "y5";
            break;
        case y6:
            cout << "y6";
            break;
        case y7:
            cout << "y7";
            break;
        case y8:
            cout << "y8";
            break;
        case y9:
            cout << "y9";
            break;
        case y10:
            cout << "y10";
            break;
        case y11:
            cout << "y11";
            break;
        case y12:
            cout << "y12";
            break;
        case y13:
            cout << "y13";
            break;
        case y14:
            cout << "y14";
            break;
        case y15:
            cout << "y15";
            break;
        case y16:
            cout << "y16";
            break;
        case y17:
            cout << "y17";
            break;
        case y18:
            cout << "y18";
            break;
        case y19:
            cout << "y19";
            break;
        case y20:
            cout << "y20";
            break;
        case y21:
            cout << "y21";
            break;
        case t21:
            cout << "t21";
            break;
        case t22:
            cout << "t22";
            break;
        case t23:
            cout << "t23";
            break;
        case t24:
            cout << "t24";
            break;
        case t41:
            cout << "t41";
            break;
        case t42:
            cout << "t42";
            break;
        case t43:
            cout << "t43";
            break;
        case t44:
            cout << "t44";
            break;
        case t45:
            cout << "t45";
            break;
    }
}

void print_state() {
    for (auto s: state) {
        print_v_type(s.v);
        cout << " = ";
        for (auto x: s.gen) {
            print_v_type(x);
            cout << " ^ ";
        }
        cout << endl;
    }
    cout << endl;
    cout << endl;
}

int expand_classified(vector<result> &results) {
    int gates = 0;
    results.clear();
    for (int i = 0; i < groups.size(); i++) {
        srand(time(NULL));
        vector<v_type> used_x;
        for (auto exp_v: groups[i]) {
            vector<v_type> list;
            v_type rep = select_and_prep_list(exp_v, list, used_x);
            result r{exp_v, rep, list};
            results.push_back(r);
            used_x.push_back(rep);
            update_state(list, rep);
#if EPAND_TYPE == Y
            if (i < 3) gates += 2 * (int) list.size();
            else gates += list.size();

#elif EPAND_TYPE == T
            gates += list.size();
#endif

        }
    }
;
    return gates;
}

void execute_expand() {
    state = state_cpy;
    vector<result> results;
    int min = expand_classified(results);
    for (auto r: results) {
        print_v_type(r.v1);
        cout << " :";
        print_v_type(r.v2);
        cout << " = ";
        print_v_type(r.v2);
        cout << " ^ ";
        for (auto x: r.gen) {
            print_v_type(x);
            cout << " ^ ";
        }
        cout << endl;
    }
    int x;
    while (true) {
        state = state_cpy;
        x = expand_classified(results);
        if (min > x) {
            min = x;
            printf("min : %d\n", min);
            for (auto r: results) {
                print_v_type(r.v1);
                cout << " :";
                print_v_type(r.v2);
                cout << " = ";
                print_v_type(r.v2);
                cout << " ^ ";
                for (auto x: r.gen) {
                    print_v_type(x);
                    cout << " ^ ";
                }
                cout << endl;
            }
        }
    }
}