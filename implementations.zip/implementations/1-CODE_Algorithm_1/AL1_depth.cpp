
#include "expand.h"
#include <bitset>
#include <random>
#include <iostream>

using namespace std;

#define ORI 0
#define INV 1

#define SBOX_TYPE ORI


#if SBOX_TYPE == ORI

const type_y y[22]{
    // 0b10000000, 0b10000110, 0b10000111, 0b11100111,
    //                0b10001110, 0b11000110, 0b11011001, 0b11110010,
    //                0b00100001, 0b00001001, 0b01011111, 0b01110010,
    //                0b01101001, 0b01000001, 0b00101000, 0b01011001,
    //                0b01110100, 0b00101101, 0b01110101, 0b01111110,
    //                0b01111011, 0b00110101

0b00100101,
0b10011000,
0b11010010,
0b00001001,
0b11001010,
0b00001010,
0b00001011,
0b11001110,
0b00000011,
0b00011000,
0b10010011,
0b11101011,
0b11000011,
0b11011000,
0b00011011,
0b00101110,
0b01010110,
0b01111000,
0b00011100,
0b10010000,
0b11110011,
0b10001110
               };

const vector<expression_t> impl_U{
        {1,  t21, y[12], y[15]},
        {3,  t21, y[3],  y[6]},
        {4,  t22, y[4],  y[0]},
        {5,  t22, y[8],  y[10]},
        {6,  t23, y[14], y[17]},
        {8,  t23, y[5],  y[1]},
        {9,  t23, y[13], y[16]},
        {10, t24, y[2],  y[7]},
        {11, t24, y[13], y[16]},
        {12, t24, y[8],  y[10]},
        {13, a,   y[9],  y[11]},
        {15, a,   y[9],  y[11]}
};

const vector<barrier> barrier_U{
        {2,  t21},
        {7,  t23},
        {14, a}
};

#elif SBOX_TYPE == INV
const type_y y[22]{0b01101000,0b00111010,0b01100111,0b11100100,0b00100001,
                   0b00000011,0b00100111,0b00010011,0b01010010,0b00100011,
                   0b11010001,0b00010111,0b00001111,0b00000110,0b11011110,
                   0b00010001,0b10000011,0b00110100,0b01000000,0b10110111,
                   0b00110001,0b10001111};


const vector<expression_t> impl_U{

};


const vector<barrier> barrier_U{

};
#endif



bool operator==(const expression_t &t1, const expression_t &t2) {
    return t1.index == t2.index;
}

inline bool in_C(vector<par_C> &C, expression_t &exp) {
    for (auto c: C) {
        auto res = find(begin(c), end(c), exp);
        if (res == end(c))
            continue;
        else return true;
    }
    return false;
}

inline bool can_move(const par_C &C, const expression_t &exp) {
    int s = C[0].index;
    int e = exp.index;
    for (auto b: barrier_U) {
        if (s < e) {
            if (b.index > s && b.index < e) {
                if (exp.t == b.t) {
                    return false;
                }
            }
        } else {
            if (b.index > e && b.index < s) {
                if (exp.t == b.t) {
                    return false;
                }
            }
        }
    }
    return true;
}

inline bool is_no_shares_t(const par_C &C, const expression_t &exp) {
    for (auto e: C) {
        if (e.t == exp.t) return false;
    }
    return true;
}

inline bool is_not_share_middle_right(const par_C &C, const expression_t &exp) {
    for (auto e: C) {
        if (e.middle == exp.middle || e.middle == exp.right || e.right == exp.right || e.right == exp.middle)
            return false;
    }
    return true;
}

inline bool is_independent(const par_C &C, const expression_t &exp) {
    vector<bitset<8>> list;
    for (auto e: C) {
        list.push_back(e.middle);
        list.push_back(e.right);
    }
    list.push_back(exp.middle);
    list.push_back(exp.right);
    int n = list.size();
    int doing = 0;
    for (int i = 7; i >= 0; --i) {
        if (list[doing][i] != 1) {
            bool find = false;
            for (int j = doing + 1; j < n; ++j) {
                if (list[j][i] == 1) {
                    swap(list[doing], list[j]);
                    find = true;
                    break;
                }
            }
            if (!find)
                continue;
        }
        for (int j = doing + 1; j < n; ++j) {
            if (list[j][i] == 1) {
                list[j] ^= list[doing];
            }
        }
        doing++;
    }
    for (auto b: list) {
        if (b.none()) return false;
    }
    return true;
}

inline bool is_C_not_full(par_C &C) {
    if (C.size() <= 3) return true;
    else return false;
}


bool can_add_to_C(par_C &C, expression_t &exp) {
    return can_move(C, exp) && is_no_shares_t(C, exp) && is_not_share_middle_right(C, exp) && is_independent(C, exp) &&
           is_C_not_full(C);
}

void print_impl(const vector<par_C> &C) {
    for (const auto &c: C) {
        for (auto e: c) {
            cout << e.index << " " << e.middle << " " << e.right << endl;
        }
        cout << endl;
    }
}

int optimize_U() {
    default_random_engine randomEngine;
    vector<par_C> C;
    C.emplace_back();
    C[C.size() - 1].push_back(impl_U[0]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_U[6]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_U[11]);


    for (auto exp: impl_U) {
        if (in_C(C, exp)) continue;
        vector<int> can_add;
        for (int i = 0; i < C.size(); ++i)
            if (can_add_to_C(C[i], exp))
                can_add.push_back(i);
        if (can_add.empty()) {
            C.emplace_back();
            C[C.size() - 1].push_back(exp);
        } else {
            srand(time(NULL));
            int r = rand() % can_add.size();
            C[can_add[r]].push_back(exp);
        }
    }
    if (C.size() == 3) {
        print_impl(C);
    }
    return C.size();
}