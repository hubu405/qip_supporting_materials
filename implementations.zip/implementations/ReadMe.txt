
1.The files in '1-CODE_Algorithm_1' is the implementation of algorithm 1.
	Algorithm 1 is used to classify the operations that can be applied in parallel;


2. The files in '2-NCT-based_Circuits_for_S-box_and_invS-box' are the NCT-based circuits constructed for AES S-box and its inverse:
	
	a). 'E-of-AES-invSbox-f_1-S_4-f_2.cpp' is the file that will be expanded (i.e., the intermediate variables y_i and t_j will be 
	calculated under S-Xor metric) for AES S-box^{-1};

	b). 'E-of-AES-Sbox-f_1-S_4-f_2.cpp' is the file that will be expanded (i.e., the intermediate variables y_i and t_j will be 
	calculated under S-Xor metric) for AES S-box;

	c). 'NCT-based_Circuit_of_AES-invSbox.cpp' is the final NCT-based circuit of AES S-box^{-1};

	d). 'NCT-based_Circuit_of_AES-Sbox.cpp' is the final NCT-based circuit of AES S-box;


3.The files in '3-CODE_Algorithm_2' is the implementation of algorithm 2.
	Algorithm 2 is used to calculate the y_0, y_1,…,y_{21} in the operations returned by Algorithm 1 under S-Xor metric;

	a). 'expand_y_for_invS-box_from_BP.cpp' is used to search the optimized S-Xor implementation of y_i when the classical circuit 
	of the S-box presented in [5] is used to construct the reversible circuit for AES S-box^{-1};

	b). 'expand_y_for_invS-box_from_Zou.cpp' is used to search the optimized S-Xor implementation of y_i when the classical circuit
	of the S-box^{-1} presented in [32] is used to construct the reversible circuit for AES S-box^{-1};

	c). 'expand_y_for_S-box_from_BP.cpp' is used to search the optimized S-Xor implementation of y_i when the classical circuit of 
	the S-box presented in [5] is used to construct the reversible circuit for AES S-box.


	Note that the t_i in the operations returned by Algorithm 1 for AES S-box can also be calculated under S-Xor metric with t_{21}, 
	t_{22}, t_{23}, t_{24} (for AES S-box^{-1}, the t_i in the operations returned by Algorithm 1 can be calculated under S-Xor 
	metric with t_{18}, t_{20}, t_{22}, t_{24}). Therefore, we alter the code for calculate y_i for t_i:

	d). 'expand_t_for_invS-box.cpp' is used to search the optimized S-Xor implementation of t_i when the classical circuit of the 
	S-box presented in [5] is used to construct the reversible circuit for AES S-box^{-1};

	e). 'expand_t_for_invS-box.cpp' is used to search the optimized S-Xor implementation of t_i when the classical circuit of the 
	S-box presented in [5] is used to construct the reversible circuit for AES S-box.



[5]: Boyar, J., Peralta, R.: A new combinational logic minimization technique with applications to cryptology. In: Festa, Paola., (eds.), Experimental Algorithms, 9th International Symposium, SEA 2010, Ischia Island, Naples, Italy, May 20-22, 2010. Proceedings, vol. 6049 of Lecture Notes in Computer Science, pages 178–189. Springer, (2010)

[32]: Zou, J., Wei, Z., Sun, S., Liu, X., Wu, W.: Quantum circuit implementations of aes with fewer qubits. In: Advances in Cryptology - ASIACRYPT 2020 - the 26th Annual International Conference on the Theory and Application of Cryptology and Information Security, Lecture Notes in Computer Science, pp. 697–726. Springer, (2020)